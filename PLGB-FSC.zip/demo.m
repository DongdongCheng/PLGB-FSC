% load dataset
fea = readtable('./data/Sucancer_X_1_0_.csv','ReadVariableNames', false);
label_orig = readtable('./data/Sucancer_Y_1_0_.csv','ReadVariableNames', false);
fea = table2array(fea);
label_orig = table2array(label_orig);

% Parameters Setting
k = 2;
p1 = 400; 
p2 = 200;

seed.end = 5;
seed.start = 1;
interval = seed.end - seed.start + 1;
ac_sum = 0;
nmi_sum = 0;
fm_sum = 0;
time_all = 0;

for i = seed.start : seed.end  
    fprintf('Seed No: %d\n',i);
    tic;
    label = pure_ball_hu(fea, p1, p2, k);
    time_once = toc;
    time_all = time_once + time_all;
    label = bestMap(label_orig,label);
    nmi_result = nmi(label,label_orig);  
    ac_result = length(find(label_orig == label))/length(label);
    [fmeasure,~]=Fmeasure(label_orig,label);
    fprintf('nmi: %.2f%% +', nmi_result * 100);
    fprintf('ac: %.2f%% + ', ac_result * 100);
    fprintf('FmeasureScores: %.2f%% + ', fmeasure * 100);
    fprintf("runtime: %.2f \n", time_once);
    nmi_sum = nmi_result + nmi_sum;
    ac_sum = ac_result + ac_sum; 
    fm_sum = fmeasure + fm_sum;
    fprintf('**************************************************************\n');
end
    nmi_avg = nmi_sum / interval;
    ac_avg = ac_sum / interval;
    fm_avg = fm_sum / interval;
    time_avg = time_all / interval;
    fprintf('avg_nmi: %.2f%% + ', nmi_avg * 100);
    fprintf('avg_ac: %.2f%% + ', ac_avg * 100);
    fprintf('avg_fm: %.2f%% + ', fm_avg * 100);
    fprintf('avg_runtime: %.2f s\n\n\n', time_avg);
    fprintf('Algorithm Finished\n');

