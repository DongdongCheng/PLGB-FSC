function labels = Tcut(fea, centerDist, N, g, Ks)
K = 5; % The number of nearest neighbors.
cntTcutKmReps = 3; 
maxTcutKmIters = 100; 

[knnIdx,knnDist] = knnsearch(centerDist,fea,'k',5);
knnMeanDiff = mean(knnDist(:)); 
Gsdx = exp(-(knnDist.^2)/(2*knnMeanDiff^2));
clear knnDist knnMeanDiff knnTmpIdx dataDist 
Gsdx(Gsdx==0) = eps;
Gidx = repmat((1:N)',1,K);
a = Gidx(:);
b = knnIdx(:);
c = Gsdx(:);
B=sparse(Gidx(:),knnIdx(:),Gsdx(:),N,g); clear Gsdx Gidx knnIdx

labels = zeros(N, numel(Ks));
for iK = 1:numel(Ks) 
    [labels(:,iK),evec] = Tcut_for_bipartite_graph(B,Ks(iK),maxTcutKmIters,cntTcutKmReps); 
end

function [labels,evec] = Tcut_for_bipartite_graph(B,Nseg,maxKmIters,cntReps)
if nargin < 4
    cntReps = 3;
end
if nargin < 3
    maxKmIters = 100;
end

[Nx,Ny] = size(B);
if Ny < Nseg
    error('Need more columns!');
end

dx = sum(B,2);
dx(dx==0) = 1e-10;
Dx = sparse(1:Nx,1:Nx,1./dx); clear dx
Wy = B'*Dx*B;

d = sum(Wy,2);
D = sparse(1:Ny,1:Ny,1./sqrt(d)); clear d
nWy = D*Wy*D; clear Wy
nWy = (nWy+nWy')/2;


[evec,eval] = eig(full(nWy)); clear nWy   
[~,idx] = sort(diag(eval),'descend');
Ncut_evec = D*evec(:,idx(1:Nseg)); clear D

evec = Dx * B * Ncut_evec; clear B Dx Ncut_evec

evec = bsxfun( @rdivide, evec, sqrt(sum(evec.*evec,2)) + 1e-10 );

labels = kmeans(evec,Nseg,'MaxIter',maxKmIters,'Replicates',cntReps);
