function label = pure_ball_hu(fea, p1, p2, k)

samples = fea;
data = samples;

data_min = min(samples);
data_max = max(samples);
samples = (samples - data_min) ./ (data_max - data_min);
weight = ones(1, size(samples, 2));
[pse_label, ~, ~] = wkmeans(samples, k, 3, weight, 20);

pse_label = pse_label(:);
mi_scores = zeros(1, size(fea, 2));  
for i = 1:size(fea, 2)
    mi_scores(i) = mutual_info(fea(:,i), pse_label);
end

[~, idx] = sort(mi_scores, 'descend');

data = data(:, idx(1:p1));
data = [data, pse_label];

centerDist = getAnchor(data, p2); 
centerDist = centerDist(:, 1:size(centerDist, 2)-1);

fea = fea(:, idx(1:p1));

[g,~]=size(centerDist);
disp(g);
N = size(fea,1);
label = Tcut(fea, centerDist, N, g, k);

function mi = mutual_info(x, y)
num_bins = min(max(10, floor(length(x) / 10)), 100);
[x_counts, x_edges] = histcounts(x, num_bins, 'Normalization', 'probability');
[y_counts, y_edges] = histcounts(y, num_bins, 'Normalization', 'probability');

[xy_counts, ~, ~] = histcounts2(x, y, x_edges, y_edges, 'Normalization', 'probability');

p_x = x_counts;
p_y = y_counts;
p_xy = xy_counts;

p_xy = p_xy(p_xy > 0);
[p_x_grid, p_y_grid] = ndgrid(p_x, p_y);
p_x_grid = p_x_grid(p_xy > 0);
p_y_grid = p_y_grid(p_xy > 0);

mi = sum(p_xy .* log2(p_xy ./ (p_x_grid .* p_y_grid)));
 
 function last_center = getAnchor(samples, p2)
gb_list_temp = {samples};
purity = 0.95;
while true
    ball_number_old = length(gb_list_temp);
    gb_list_temp = split(gb_list_temp, purity, p2); 
    ball_number_new = length(gb_list_temp);
    if ball_number_new == ball_number_old
        break;
    end
end

m=length(gb_list_temp);
last_center=cell(m,1);
for h=1:m
    data = full(gb_list_temp{h}); 
    if size(data,1)==1 
        last_center{h,1}=data;
    else  
        last_center{h,1}=mean(data);
    end
end
last_center=cell2mat(last_center);

function granular_ball_list_new = split(granular_ball_list, purity, p2)
granular_ball_list_new = {};
j = 1;
for i = 1:length(granular_ball_list)
    gb = granular_ball_list{i};
    
    p = get_label_and_purity(gb);
    
    [m,~]=size(gb); 
    if p >= purity && m<8
        granular_ball_list_new{j, 1} = gb; 
        j = j+1;
    else
        [ball_1, ball_2] = spilt_ball_kmeans(gb, p2);
        granular_ball_list_new{j,1} = ball_1;
        granular_ball_list_new{j+1,1} = ball_2;
        j = j+ 2;
    end
end

function purity = get_label_and_purity(data)
if iscell(data) 
    data = cell2mat(data);
end
labels = data(:,size(data, 2));
label_counts = tabulate(labels);
purity = max(label_counts(:, 3))/100;

function [ball1, ball2] = spilt_ball_kmeans(data, p2)
data_no_label = data(:, 1:size(data, 2)-1);
data_no_label = discernibility(data_no_label, p2);
[label, ~] = litekmeans(data_no_label, 2 ,'MaxIter', 3,'Replicates',1);
ball1 = data(label == 1, :);
ball2 = data(label == 2, :);

function samples_no_label = discernibility(samples, p2)
stds = std(samples);
pearson_corr_matrix = corr(samples);
pearson_sum = sum(abs(pearson_corr_matrix), 2);
independence = 1 ./ pearson_sum; % n x 1

[~, max_index] = max(stds);
[min_value, ~] = min(abs(pearson_sum));
independence(max_index) = 1 ./ min_value;

result = independence .* stds';
[i, top_indices] = sort(result, 'descend');
top_indices = top_indices(1:p2);
samples_no_label = samples(:, top_indices);

data_min = min(samples_no_label);
data_max = max(samples_no_label);
samples_no_label = (samples_no_label - data_min) ./ (data_max - data_min);

