function [best_labels, best_centers, w] = wkmeans(X, K, belta, w, max_iter)
    costF = [];
    centroids = InitCentroids(X, K);
    
    for i = 1:max_iter
        idx = findClosestCentroids(X, w, centroids);
        centroids = computeCentroids(X, idx, K);
        w = computeWeight(X, centroids, idx, K, belta);
        c = costFunction(X, K, centroids, idx, w, belta);
        costF = [costF; round(c, 4)];
        
        if i < 3
            continue;
        end
        
        flag = isConvergence(costF, max_iter);
        if strcmp(flag, 'continue')
            continue;
        elseif flag
            best_labels = idx;
            best_centers = centroids;
            isConverge = true;
        else
            isConverge = false;
            best_labels = [];
            best_centers = [];
        end
    end
    best_labels = idx;
    best_centers = centroids;
end


function centroids = InitCentroids(X, K)

    n = size(X,1);
    first_idx = randi([1, n], 1);
    center = X(first_idx, :); 
    dist_note = sqrt(sum((X - center) .^ 2, 2));
    [~, next_idx] = max(dist_note); 
    centroids = zeros(K, size(X, 2));
    centroids(1, :) = center;
    centroids(2, :) = X(next_idx, :);
    if K>2
        for k = 3:K
            dist_to_centers = min(pdist2(X, centroids(1:k-1, :)), [], 2);
            probabilities = dist_to_centers.^2 / sum(dist_to_centers.^2);
            cumulative_probabilities = cumsum(probabilities);
            r = rand();
            new_center_idx = find(cumulative_probabilities >= r, 1);
            centroids(k, :) = X(new_center_idx, :);
        end
    end
end

function idx = findClosestCentroids(X, w, centroids)
    K = size(centroids, 1);
    idx = zeros(size(X, 1), 1);
    n = size(X, 1);
    for i = 1:n
        subs = centroids - X(i, :);
        dimension2 = subs.^2;
        w_dimension2 = w .* dimension2;
        w_distance2 = sum(w_dimension2, 2);
        if any(isnan(w_distance2)) || any(isinf(w_distance2))
            w_distance2 = zeros(K, 1);
        end
        [~, idx(i)] = min(w_distance2);
    end
end

function centroids = computeCentroids(X, idx, K)
    [n, m] = size(X);
    centroids = zeros(K, m);
    for k = 1:K
        index = find(idx == k);
        temp = X(index, :);
        s = sum(temp, 1);
        centroids(k, :) = s / numel(index);
    end
end

function weight = computeWeight(X, centroids, idx, K, belta)
    [n, m] = size(X);
    weight = zeros(1, m);
    D = zeros(1, m);
    for k = 1:K
        index = find(idx == k);
        temp = X(index, :);
        distance2 = (temp - centroids(k, :)).^2;
        D = D + sum(distance2, 1);
    end
    e = 1 / (belta - 1);
    for j = 1:m
        temp = D(1, j) ./ D;
        weight(1, j) = 1 / sum(temp.^e);
    end
end

function J = costFunction(X, K, centroids, idx, w, belta)
    [~, m] = size(X);
    D = zeros(1, m);
    for k = 1:K
        index = find(idx == k);
        temp = X(index, :);
        distance2 = (temp - centroids(k, :)).^2;
        D = D + sum(distance2, 1);
    end
    J = sum(w .^ belta .* D);
end

function flag = isConvergence(costF, max_iter)

    index = numel(costF);
    if index >= max_iter
        flag = true;
    elseif costF(index) == costF(index - 1) && costF(index) == costF(index - 2)
        flag = true;
    else
        flag = 'continue';
    end
end

